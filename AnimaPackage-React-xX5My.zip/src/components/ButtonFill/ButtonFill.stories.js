import { ButtonFill } from ".";

export default {
  title: "Components/ButtonFill",
  component: ButtonFill,
};

export const Default = {
  args: {
    className: {},
    editProfileClassName: {},
    text: "Edit Profile",
  },
};
